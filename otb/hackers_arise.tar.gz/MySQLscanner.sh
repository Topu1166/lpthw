#! /usr/bin/env bash 

#This script is designed to find hosts with MySQL installed 

nmap -sT 192.168.0.103/24 -p 3306 -oG MySQLscan >/dev/null 

cat MySQLscan | grep open > MySQLscan2 

cat MySQLscan2

